const express=require("express");
const session=require("express-session");
const bcrypt=require("bcryptjs");
const Database=require("better-sqlite3");
const path=require("path");
const fs=require("fs");

const app=express();
app.set("trust proxy", 1);
const dataDir=path.join(__dirname,"data");
fs.mkdirSync(dataDir,{recursive:true});
const db=new Database(path.join(dataDir,"idcard.sqlite"));
db.pragma("foreign_keys = ON");
db.exec(`
CREATE TABLE IF NOT EXISTS admins(id INTEGER PRIMARY KEY, username TEXT UNIQUE, password_hash TEXT);
CREATE TABLE IF NOT EXISTS schools(id INTEGER PRIMARY KEY, name TEXT NOT NULL, code TEXT UNIQUE NOT NULL, password_hash TEXT NOT NULL, active INTEGER DEFAULT 1, created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS id_cards(id INTEGER PRIMARY KEY, school_id INTEGER NOT NULL, type TEXT NOT NULL, data TEXT NOT NULL, created_at TEXT DEFAULT CURRENT_TIMESTAMP,
FOREIGN KEY(school_id) REFERENCES schools(id) ON DELETE CASCADE);
CREATE TABLE IF NOT EXISTS classes(id INTEGER PRIMARY KEY, name TEXT UNIQUE NOT NULL);
CREATE TABLE IF NOT EXISTS sections(id INTEGER PRIMARY KEY, name TEXT UNIQUE NOT NULL);
`);
const adminUsername=process.env.ADMIN_USERNAME||"admin";
const adminPassword=process.env.ADMIN_PASSWORD||"admin123";
if(!db.prepare("SELECT id FROM admins WHERE username=?").get(adminUsername)){
  db.prepare("INSERT INTO admins(username,password_hash) VALUES(?,?)").run(adminUsername,bcrypt.hashSync(adminPassword,10));
}
app.use(express.json({limit:"15mb"}));
app.use(session({secret:process.env.SESSION_SECRET||"change-this-secret",resave:false,saveUninitialized:false,cookie:{httpOnly:true,secure:process.env.NODE_ENV==="production",sameSite:"lax"}}));
app.use(express.static(__dirname));

app.get("/api/health",(req,res)=>res.json({ok:true,service:"alok-idcard-system",time:new Date().toISOString()}));

const adminOnly=(req,res,next)=>req.session.admin?next():res.status(401).json({error:"Admin login required"});
const schoolOnly=(req,res,next)=>req.session.school?next():res.status(401).json({error:"School login required"});

app.post("/api/admin/login",(req,res)=>{
 const a=db.prepare("SELECT * FROM admins WHERE username=?").get(req.body.username||"");
 if(a && bcrypt.compareSync(req.body.password||"",a.password_hash)){req.session.admin={id:a.id};return res.json({ok:true});}
 res.status(401).json({error:"Invalid admin login"});
});
app.get("/api/admin/me",(req,res)=>req.session.admin?res.json({ok:true,admin:true}):res.status(401).json({error:"Admin login required"}));
app.post("/api/admin/logout",(req,res)=>req.session.destroy(()=>res.json({ok:true})));

// Master data APIs used by the Admin Portal
app.get("/api/classes",adminOnly,(req,res)=>res.json(db.prepare("SELECT id,name FROM classes ORDER BY id DESC").all()));
app.post("/api/classes",adminOnly,(req,res)=>{try{const r=db.prepare("INSERT INTO classes(name) VALUES(?)").run(String(req.body.name||"").trim());res.json({ok:true,id:r.lastInsertRowid});}catch(e){res.status(400).json({error:"Class already exists or name is empty"});}});
app.put("/api/classes/:id",adminOnly,(req,res)=>{try{db.prepare("UPDATE classes SET name=? WHERE id=?").run(String(req.body.name||"").trim(),req.params.id);res.json({ok:true});}catch(e){res.status(400).json({error:"Class already exists or name is empty"});}});
app.delete("/api/classes/:id",adminOnly,(req,res)=>{db.prepare("DELETE FROM classes WHERE id=?").run(req.params.id);res.json({ok:true});});
app.get("/api/sections",adminOnly,(req,res)=>res.json(db.prepare("SELECT id,name FROM sections ORDER BY id DESC").all()));
app.post("/api/sections",adminOnly,(req,res)=>{try{const r=db.prepare("INSERT INTO sections(name) VALUES(?)").run(String(req.body.name||"").trim());res.json({ok:true,id:r.lastInsertRowid});}catch(e){res.status(400).json({error:"Section already exists or name is empty"});}});
app.put("/api/sections/:id",adminOnly,(req,res)=>{try{db.prepare("UPDATE sections SET name=? WHERE id=?").run(String(req.body.name||"").trim(),req.params.id);res.json({ok:true});}catch(e){res.status(400).json({error:"Section already exists or name is empty"});}});
app.delete("/api/sections/:id",adminOnly,(req,res)=>{db.prepare("DELETE FROM sections WHERE id=?").run(req.params.id);res.json({ok:true});});

app.get("/api/schools",adminOnly,(req,res)=>{
 res.json(db.prepare("SELECT id,name,code,active,created_at FROM schools ORDER BY id DESC").all());
});
app.post("/api/schools",adminOnly,(req,res)=>{
 const {name,code,password}=req.body;
 if(!name||!code||!password)return res.status(400).json({error:"Name, code and password required"});
 try{
  const r=db.prepare("INSERT INTO schools(name,code,password_hash) VALUES(?,?,?)").run(name,code,bcrypt.hashSync(password,10));
  res.json({ok:true,id:r.lastInsertRowid});
 }catch(e){res.status(400).json({error:"School code already exists"});}
});
app.put("/api/schools/:id",adminOnly,(req,res)=>{
 const s=db.prepare("SELECT * FROM schools WHERE id=?").get(req.params.id);
 if(!s)return res.status(404).json({error:"Not found"});
 const name=req.body.name||s.name, code=req.body.code||s.code;
 try{
  if(req.body.password) db.prepare("UPDATE schools SET name=?,code=?,password_hash=?,active=? WHERE id=?").run(name,code,bcrypt.hashSync(req.body.password,10),req.body.active?1:0,s.id);
  else db.prepare("UPDATE schools SET name=?,code=?,active=? WHERE id=?").run(name,code,req.body.active?1:0,s.id);
  res.json({ok:true});
 }catch(e){res.status(400).json({error:"School code already exists"});}
});
app.delete("/api/schools/:id",adminOnly,(req,res)=>{db.prepare("DELETE FROM schools WHERE id=?").run(req.params.id);res.json({ok:true});});

app.get("/api/admin/school/:id/cards",adminOnly,(req,res)=>{
 const rows=db.prepare("SELECT id,type,data,created_at FROM id_cards WHERE school_id=? ORDER BY id DESC").all(req.params.id);
 res.json(rows.map(x=>({...x,data:JSON.parse(x.data)})));
});

app.post("/api/schools/login",(req,res)=>{
 const s=db.prepare("SELECT * FROM schools WHERE code=?").get(req.body.code||"");
 if(s && s.active && bcrypt.compareSync(req.body.password||"",s.password_hash)){req.session.school={id:s.id,name:s.name,code:s.code};return res.json({ok:true,school:{id:s.id,name:s.name,code:s.code}});}
 res.status(401).json({error:"Invalid code/password or school inactive"});
});
app.get("/api/schools/me",(req,res)=>req.session.school?res.json({ok:true,school:req.session.school}):res.status(401).json({error:"School login required"}));
app.post("/api/schools/logout",(req,res)=>req.session.destroy(()=>res.json({ok:true})));
app.get("/api/id-cards",schoolOnly,(req,res)=>{
 const rows=db.prepare("SELECT id,type,data,created_at FROM id_cards WHERE school_id=? ORDER BY id DESC").all(req.session.school.id);
 res.json(rows.map(x=>({...x,data:JSON.parse(x.data)})));
});
app.post("/api/id-cards",schoolOnly,(req,res)=>{
 if(!req.body.type||!req.body.data)return res.status(400).json({error:"Invalid card"});
 const r=db.prepare("INSERT INTO id_cards(school_id,type,data) VALUES(?,?,?)").run(req.session.school.id,req.body.type,JSON.stringify(req.body.data));
 res.json({ok:true,id:r.lastInsertRowid});
});
app.delete("/api/id-cards/:id",schoolOnly,(req,res)=>{
 db.prepare("DELETE FROM id_cards WHERE id=? AND school_id=?").run(req.params.id,req.session.school.id);
 res.json({ok:true});
});
// Friendly browser routes (similar to the reference site's URL structure)
app.get("/",(req,res)=>res.sendFile(path.join(__dirname,"user.html")));
app.get("/User/Login",(req,res)=>res.sendFile(path.join(__dirname,"user.html")));
app.get("/Admin/AAccount/Login",(req,res)=>res.sendFile(path.join(__dirname,"admin.html")));
app.get("/Admin",(req,res)=>res.sendFile(path.join(__dirname,"admin.html")));
const PORT=process.env.PORT||3000;
app.listen(PORT,"0.0.0.0",()=>console.log("ID Card system running on port "+PORT));
