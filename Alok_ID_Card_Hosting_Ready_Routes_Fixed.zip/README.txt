ALOK COMPUTERS - ID CARD SYSTEM

This is a Node.js + Express + SQLite ID Card Management System.
Admin and School/User are separate pages connected to one shared SQLite database.

QUICK START
1. Install Node.js 18 or newer.
2. Open a terminal in this folder.
3. npm install
4. npm start
5. Admin: http://localhost:3000/admin.html
6. School/User: http://localhost:3000/user.html

DEFAULT ADMIN (first fresh database only)
Username: admin
Password: admin123

Admin can create schools, enable/disable school login, view ID cards and export school data.
Schools can log in and create Student, Teacher and Staff ID cards.

IMPORTANT FOR PUBLIC HOSTING
Use persistent storage because SQLite stores the application data in data/idcard.sqlite.
Set SESSION_SECRET and a strong ADMIN_PASSWORD as environment variables.
Do not expose the .env file.

HEALTH CHECK
http://localhost:3000/api/health
